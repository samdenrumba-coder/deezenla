alert ("I FULLSCREEN SA BABY PRESS F11 OR FN + 11");

setTimeout(function() {

    window.location.href = "loading.html";
}, 3000);
    