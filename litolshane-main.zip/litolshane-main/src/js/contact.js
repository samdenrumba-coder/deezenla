document.getElementById("heart-link").addEventListener("click", function(event) {
    event.preventDefault();
    window.location.href = "choices.html";
});
